bulk_ISMacro <- function(countexp, method = "VISION", imputation = F, type = "ISM") {
  library(VISION)
  library(AUCell)
  library(GSEABase)
  library(GSVA)
  library(progress)
  signatures_ISMacro <- system.file("data", "ISMacro.gmt", package = "ISMacro")

  if (metabolism.type == "ISM")  {gmtFile<-signatures_ISMacro; cat("You have entered the gene set correctly")}

  if (imputation == FALSE) {
    countexp2 <- countexp
  } else if (imputation == TRUE) {
    cat("Filling missing values\n")
    result.completed <- alra(as.matrix(countexp))
    countexp2 <- result.completed[[3]]
    row.names(countexp2) <- row.names(countexp)
  }

  cat("[1] ISM activity scoring in progress\n")
  # VISION
  if (method == "VISION") {
    cat("[2] VISION-----ISM pathway activity scoring in progress\n")

    pb <- progress_bar$new(
      format = "  [:bar] :percent :elapsedfull",
      total = 5,  # 总的步骤数
      clear = FALSE
    )

    n.umi <- colSums(count_exp)
    pb$tick()
    cat("    Step 1: Calculated total UMI counts.\n")

    scaled_counts <- t(t(count_exp) / n.umi) * median(n.umi)
    pb$tick()
    cat("    Step 2: Scaled count matrix based on UMI counts.\n")

    vis <- Vision(scaled_counts, signatures = gmtFile)
    pb$tick()
    cat("    Step 3: Created Vision object with scaled counts and signatures.\n")

    options(mc.cores = ncores)
    vis <- analyze(vis)
    pb$tick()
    cat("    Step 4: Analyzed Vision object with multiple cores---Slightly slow, please wait patiently.\n")

    signature_exp <- data.frame(t(vis@SigScores))
    pb$tick()
    cat("    Step 5: Transformed signature scores into data frame.\n")
  }

  # AUCell
  if (method == "AUCell") {
    cat("[2] AUCell-----ISM activity scoring in progress\n")

    pb <- progress_bar$new(
      format = "  [:bar] :percent :elapsedfull",
      total = 4,  # 总的步骤数
      clear = FALSE
    )

    cells_rankings <- AUCell_buildRankings(as.matrix(count_exp), nCores = ncores, plotStats = F)
    pb$tick()
    cat("  Step 1: Built cell rankings.\n")

    geneSets <- getGmt(gmtFile)
    pb$tick()
    cat("  Step 2: Loaded gene sets from GMT file.\n")

    cells_AUC <- AUCell_calcAUC(geneSets, cells_rankings)
    pb$tick()
    cat("  Step 3: Calculated AUC scores for cells.\n")

    signature_exp <- data.frame(getAUC(cells_AUC))
    pb$tick()
    cat("  Step 4: Transformed AUC scores into data frame.\n")
  }

  # ssGSEA
  if (method == "ssGSEA") {
    cat("ssGSEA-----ISM activity scoring in progress\n")

    pb <- progress_bar$new(
      format = "  [:bar] :percent :elapsedfull",
      total = 4,  # 总的步骤数
      clear = FALSE
    )

    geneSets <- getGmt(gmtFile)
    pb$tick()
    cat("Step 1: Loaded gene sets from GMT file.\n")

    gsva_es <- gsva(as.matrix(count_exp), geneSets, method = "ssgsea", kcdf = "Poisson", parallel.sz = ncores)
    pb$tick()
    cat("Step 2: Calculated ssGSEA enrichment scores.\n")

    signature_exp <- data.frame(gsva_es)
    pb$tick()
    cat("Step 3: Transformed enrichment scores into data frame.\n")
  }

  # GSVA
  if (method == "gsva") {
    cat("GSVA-----ISM activity scoring in progress\n")

    pb <- progress_bar$new(
      format = "  [:bar] :percent :elapsedfull",
      total = 4,  # 总的步骤数
      clear = FALSE
    )

    geneSets <- getGmt(gmtFile)
    pb$tick()
    cat("Step 1: Loaded gene sets from GMT file.\n")

    gsva_es <- gsva(as.matrix(count_exp), geneSets, method = "gsva", kcdf = "Poisson", parallel.sz = ncores)
    pb$tick()
    cat("Step 2: Calculated GSVA enrichment scores.\n")

    signature_exp <- data.frame(gsva_es)
    pb$tick()
    cat("Step 3: Transformed enrichment scores into data frame.\n")
  }

  cat("[3] Thank you very much for using our R package and hope it is helpful to you. If possible, the relevant citations are as follows: AAA\n")
  signature_exp
}



